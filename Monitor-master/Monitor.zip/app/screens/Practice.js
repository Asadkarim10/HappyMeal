import React, { Component } from 'react';
import { View, Text, StyleSheet,Linking, TouchableOpacity, ImageBackground, Image, ScrollView } from 'react-native'
//import { black } from 'react-native-paper/lib/typescript/src/styles/colors';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';

class Practice extends Component { 

 
    render() {  
      return (

        <View>
            <Text>Mustansar</Text>
        </View>

      )
    }
}

export default Practice;