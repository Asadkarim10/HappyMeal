import { AUTH } from './constant';


export const emergencymessage= payload => ({
  type: AUTH.EMERGENCYMESSAGE,
  payload
});

